# 🎬 Rika Events Video Portal — APK Build Guide

## App Overview
A branded video recording app for **Rika Events** that lets staff record short event videos (15s–1min) with the Rika logo watermark and instantly send them to clients via WhatsApp.

---

## ✅ Features in This Version
- 📷 Camera preview with front/rear flip
- ⏱ Duration selector: 15s / 30s / 45s / 1 Min
- 🎨 Watermark: toggle between Logo image or Custom text
- 💾 Save to gallery
- 📲 Direct WhatsApp share with pre-filled message
- 🔴 Circular recording progress indicator
- 🛡️ Proper permission handling (Android 13+ compatible)
- 🚀 Portrait-locked, full-screen camera UI

---

## 📋 Prerequisites

1. **Flutter SDK** (3.x or later) — https://docs.flutter.dev/get-started/install
2. **Android Studio** with Android SDK installed
3. **Java JDK 17** (recommended)
4. A physical Android device or emulator (API 21+)

---

## 🔧 Build Steps

### Step 1 — Install Flutter & verify
```bash
flutter doctor
```
Make sure Android toolchain shows ✅ with no critical errors.

---

### Step 2 — Enter project directory
```bash
cd rika_video_app
```

---

### Step 3 — Install dependencies
```bash
flutter pub get
```

---

### Step 4 — Build Debug APK (for testing)
```bash
flutter build apk --debug
```
APK output: `build/app/outputs/flutter-apk/app-debug.apk`

---

### Step 5 — Build Release APK (for distribution)
```bash
flutter build apk --release
```
APK output: `build/app/outputs/flutter-apk/app-release.apk`

---

### Step 6 — Install directly on connected Android device
```bash
flutter install
```
Or manually copy the APK to your phone and install (enable "Unknown sources" in settings).

---

## 📦 Package Structure
```
rika_video_app/
├── lib/
│   └── main.dart              ← Main app code
├── assets/
│   └── images/
│       └── logo.png           ← Rika Events logo (watermark)
├── android/
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── kotlin/com/rikaevents/video/MainActivity.kt
│   │       └── res/
│   │           ├── mipmap-*/ic_launcher*.png   ← App icons
│   │           └── values/styles.xml
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
└── pubspec.yaml
```

---

## 🔑 Signing for Production (Play Store)

### Generate a keystore:
```bash
keytool -genkey -v -keystore rika_events.keystore \
  -alias rika_events -keyalg RSA -keysize 2048 -validity 10000
```

### Create `android/key.properties`:
```
storePassword=<your_store_password>
keyPassword=<your_key_password>
keyAlias=rika_events
storeFile=../rika_events.keystore
```

### Update `android/app/build.gradle` signingConfigs to use keystore.

---

## ⚠️ Important Notes

1. **Real device strongly recommended** — camera features may not work on emulators.
2. **WhatsApp integration** — opens WhatsApp with a pre-written message; the video file must be shared manually from gallery since direct file attachment via URL scheme requires WhatsApp Business API.
3. **Watermark is a preview overlay only** — it shows on screen but is NOT burned into the video file. Burning watermarks into video requires FFmpeg integration (e.g., `ffmpeg_kit_flutter` package).
4. **Minimum Android version**: API 21 (Android 5.0 Lollipop).

---

## 📞 Contact
Rika Events — *Luxury in every layer, Perfection in every plan.*
