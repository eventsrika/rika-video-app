import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:gallery_saver/gallery_saver.dart';

List<CameraDescription> cameras = [];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Lock to portrait mode
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  try {
    cameras = await availableCameras();
  } on CameraException catch (e) {
    debugPrint('Error initializing cameras: $e');
  }
  runApp(const RikaVideoApp());
}

class RikaVideoApp extends StatelessWidget {
  const RikaVideoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rika Events Video Portal',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        primaryColor: const Color(0xFF4CB5C4),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF4CB5C4),
          secondary: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF4CB5C4),
            foregroundColor: Colors.black,
          ),
        ),
      ),
      home: const VideoRecorderScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class VideoRecorderScreen extends StatefulWidget {
  const VideoRecorderScreen({super.key});

  @override
  State<VideoRecorderScreen> createState() => _VideoRecorderScreenState();
}

class _VideoRecorderScreenState extends State<VideoRecorderScreen>
    with WidgetsBindingObserver {
  CameraController? _cameraController;
  bool _isRecording = false;
  int _selectedDuration = 15;
  int _secondsRemaining = 15;
  Timer? _countdownTimer;
  XFile? _recordedVideo;
  bool _isFrontCamera = false;
  bool _isCameraInitializing = false;

  // Watermark
  bool _useImageLogo = true;
  bool _showWatermark = true;
  final TextEditingController _customTextController =
      TextEditingController(text: "RIKA EVENTS");
  final TextEditingController _whatsappController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _requestPermissions();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_cameraController == null || !_cameraController!.value.isInitialized) return;
    if (state == AppLifecycleState.inactive) {
      _cameraController?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      _initializeCamera(cameraIndex: _isFrontCamera ? 1 : 0);
    }
  }

  Future<void> _requestPermissions() async {
    final statuses = await [
      Permission.camera,
      Permission.microphone,
      Permission.storage,
    ].request();

    bool allGranted = statuses.values.every((s) => s.isGranted);
    if (allGranted) {
      _initializeCamera();
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Camera & microphone permissions are required."),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _initializeCamera({int cameraIndex = 0}) async {
    if (cameras.isEmpty) return;
    if (_isCameraInitializing) return;

    setState(() => _isCameraInitializing = true);

    final CameraController newController = CameraController(
      cameras[cameraIndex < cameras.length ? cameraIndex : 0],
      ResolutionPreset.high,
      enableAudio: true,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );

    try {
      await _cameraController?.dispose();
      _cameraController = newController;
      await _cameraController!.initialize();
      if (mounted) {
        setState(() {
          _isFrontCamera = cameraIndex == 1;
          _isCameraInitializing = false;
        });
      }
    } catch (e) {
      debugPrint("Camera init error: $e");
      setState(() => _isCameraInitializing = false);
    }
  }

  Future<void> _flipCamera() async {
    if (_isRecording) return;
    int newIndex = _isFrontCamera ? 0 : 1;
    await _initializeCamera(cameraIndex: newIndex);
  }

  void _startTimer() {
    _secondsRemaining = _selectedDuration;
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_secondsRemaining > 0) {
        setState(() => _secondsRemaining--);
      } else {
        timer.cancel();
        _stopVideoRecording();
      }
    });
  }

  Future<void> _startVideoRecording() async {
    if (_cameraController == null ||
        !_cameraController!.value.isInitialized ||
        _isRecording) return;

    try {
      await _cameraController!.startVideoRecording();
      setState(() {
        _isRecording = true;
        _recordedVideo = null;
      });
      _startTimer();
    } catch (e) {
      debugPrint("Error starting recording: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Could not start recording: $e")),
        );
      }
    }
  }

  Future<void> _stopVideoRecording() async {
    if (_cameraController == null || !_cameraController!.value.isRecording) return;

    _countdownTimer?.cancel();
    try {
      XFile videoFile = await _cameraController!.stopVideoRecording();
      setState(() {
        _isRecording = false;
        _recordedVideo = videoFile;
      });
      _showShareBottomSheet();
    } catch (e) {
      debugPrint("Error stopping recording: $e");
      setState(() => _isRecording = false);
    }
  }

  Future<void> _saveToGallery() async {
    if (_recordedVideo == null) return;
    try {
      bool? saved = await GallerySaver.saveVideo(_recordedVideo!.path);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(saved == true ? "✅ Video saved to gallery!" : "❌ Save failed"),
            backgroundColor: saved == true ? Colors.green : Colors.red,
          ),
        );
      }
    } catch (e) {
      debugPrint("Gallery save error: $e");
    }
  }

  Future<void> _sendViaWhatsApp() async {
    String phone = _whatsappController.text.trim().replaceAll(RegExp(r'[\s\-()]'), '');

    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please enter a WhatsApp number"),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    // Normalize phone number
    if (phone.startsWith('+')) {
      phone = phone.substring(1);
    } else if (!phone.startsWith('91') && phone.length == 10) {
      phone = '91$phone';
    }

    const String message =
        "🎉 Hello! Here is your event video from *Rika Events*.\n\n"
        "✨ _Luxury in every layer, Perfection in every plan._\n\n"
        "Thank you for letting us be part of your special day! 🎊";

    final String url = "https://wa.me/$phone?text=${Uri.encodeComponent(message)}";

    try {
      if (await canLaunchUrl(Uri.parse(url))) {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("WhatsApp not installed or number invalid"),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint("WhatsApp launch error: $e");
    }
  }

  void _showShareBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E1E1E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Handle bar
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.check_circle, color: Color(0xFF4CB5C4), size: 22),
                  const SizedBox(width: 8),
                  const Text(
                    "Video Recorded Successfully!",
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF4CB5C4),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Save to gallery button
              OutlinedButton.icon(
                onPressed: _saveToGallery,
                icon: const Icon(Icons.save_alt, color: Color(0xFF4CB5C4)),
                label: const Text(
                  "Save to Gallery",
                  style: TextStyle(color: Color(0xFF4CB5C4)),
                ),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF4CB5C4)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),

              const Divider(color: Colors.white12),
              const SizedBox(height: 12),

              const Text(
                "Send via WhatsApp",
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _whatsappController,
                keyboardType: TextInputType.phone,
                style: const TextStyle(fontSize: 15),
                decoration: InputDecoration(
                  labelText: "Client WhatsApp Number",
                  hintText: "e.g. 9876543210 or +919876543210",
                  prefixIcon: const Icon(Icons.whatsapp, color: Color(0xFF4CB5C4)),
                  filled: true,
                  fillColor: const Color(0xFF2A2A2A),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF4CB5C4)),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              ElevatedButton.icon(
                onPressed: _sendViaWhatsApp,
                icon: const Icon(Icons.send),
                label: const Text(
                  "Open WhatsApp & Send Message",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool cameraReady =
        _cameraController != null && _cameraController!.value.isInitialized;

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            // Camera preview
            if (cameraReady)
              Positioned.fill(
                child: AspectRatio(
                  aspectRatio: _cameraController!.value.aspectRatio,
                  child: CameraPreview(_cameraController!),
                ),
              )
            else
              const Positioned.fill(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: Color(0xFF4CB5C4)),
                      SizedBox(height: 16),
                      Text("Initializing Camera...",
                          style: TextStyle(color: Colors.white54)),
                    ],
                  ),
                ),
              ),

            // Top bar
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Image.asset(
                      'assets/images/logo.png',
                      height: 36,
                      errorBuilder: (c, o, s) => const Text(
                        "RIKA EVENTS",
                        style: TextStyle(
                            color: Color(0xFF4CB5C4),
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2),
                      ),
                    ),
                    if (_isRecording)
                      Container(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.85),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.fiber_manual_record,
                                color: Colors.white, size: 10),
                            const SizedBox(width: 5),
                            Text(
                              "REC  ${_secondsRemaining}s",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    // Flip camera button
                    if (cameras.length > 1)
                      IconButton(
                        onPressed: _isRecording ? null : _flipCamera,
                        icon: Icon(
                          Icons.flip_camera_ios,
                          color: _isRecording ? Colors.white30 : Colors.white,
                        ),
                      ),
                  ],
                ),
              ),
            ),

            // Watermark overlay
            if (_showWatermark && cameraReady)
              Positioned(
                top: 70,
                right: 16,
                child: Opacity(
                  opacity: 0.70,
                  child: _useImageLogo
                      ? Image.asset(
                          'assets/images/logo.png',
                          width: 100,
                          errorBuilder: (c, o, s) => Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            color: Colors.black54,
                            child: const Text("RIKA EVENTS",
                                style: TextStyle(
                                    color: Color(0xFF4CB5C4),
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold)),
                          ),
                        )
                      : Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            _customTextController.text.isEmpty
                                ? "RIKA EVENTS"
                                : _customTextController.text,
                            style: const TextStyle(
                              color: Color(0xFF4CB5C4),
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ),
                ),
              ),

            // Bottom controls panel
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black, Colors.black87, Colors.transparent],
                  ),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                ),
                padding:
                    const EdgeInsets.only(left: 20, right: 20, top: 16, bottom: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Watermark controls
                    Row(
                      children: [
                        const Icon(Icons.branding_watermark,
                            color: Colors.white54, size: 16),
                        const SizedBox(width: 6),
                        const Text("Watermark:",
                            style:
                                TextStyle(fontSize: 12, color: Colors.white54)),
                        const Spacer(),
                        const Text("Logo",
                            style: TextStyle(
                                fontSize: 12, color: Colors.white70)),
                        Switch(
                          value: !_useImageLogo,
                          activeColor: const Color(0xFF4CB5C4),
                          inactiveThumbColor: const Color(0xFF4CB5C4),
                          onChanged: _isRecording
                              ? null
                              : (val) {
                                  setState(() => _useImageLogo = !val);
                                },
                        ),
                        const Text("Text",
                            style: TextStyle(
                                fontSize: 12, color: Colors.white70)),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () =>
                              setState(() => _showWatermark = !_showWatermark),
                          child: Icon(
                            _showWatermark
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: const Color(0xFF4CB5C4),
                            size: 22,
                          ),
                        ),
                      ],
                    ),

                    if (!_useImageLogo && !_isRecording)
                      Padding(
                        padding: const EdgeInsets.only(top: 8, bottom: 4),
                        child: TextField(
                          controller: _customTextController,
                          style: const TextStyle(fontSize: 13),
                          decoration: InputDecoration(
                            hintText: "Brand text on video...",
                            isDense: true,
                            filled: true,
                            fillColor: const Color(0xFF2A2A2A),
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 10, horizontal: 12),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide.none,
                            ),
                          ),
                          onChanged: (v) => setState(() {}),
                        ),
                      ),

                    const SizedBox(height: 10),
                    const Divider(color: Colors.white12, height: 1),
                    const SizedBox(height: 12),

                    // Duration selector
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [15, 30, 45, 60].map((int dur) {
                        final bool selected = _selectedDuration == dur;
                        final String label = dur == 60 ? "1 Min" : "${dur}s";
                        return GestureDetector(
                          onTap: _isRecording
                              ? null
                              : () => setState(() {
                                    _selectedDuration = dur;
                                    _secondsRemaining = dur;
                                  }),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 8),
                            decoration: BoxDecoration(
                              color: selected
                                  ? const Color(0xFF4CB5C4)
                                  : const Color(0xFF2A2A2A),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: selected
                                    ? const Color(0xFF4CB5C4)
                                    : Colors.white12,
                              ),
                            ),
                            child: Text(
                              label,
                              style: TextStyle(
                                color:
                                    selected ? Colors.black : Colors.white70,
                                fontWeight: selected
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),

                    const SizedBox(height: 20),

                    // Record button + progress indicator
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        if (_isRecording)
                          SizedBox(
                            width: 84,
                            height: 84,
                            child: CircularProgressIndicator(
                              value: 1 -
                                  (_secondsRemaining / _selectedDuration),
                              color: Colors.red,
                              strokeWidth: 3,
                              backgroundColor: Colors.white12,
                            ),
                          ),
                        GestureDetector(
                          onTap: _isRecording
                              ? _stopVideoRecording
                              : _startVideoRecording,
                          child: CircleAvatar(
                            radius: 36,
                            backgroundColor: Colors.white,
                            child: CircleAvatar(
                              radius: 32,
                              backgroundColor: _isRecording
                                  ? Colors.red
                                  : const Color(0xFF4CB5C4),
                              child: Icon(
                                _isRecording ? Icons.stop : Icons.videocam,
                                color: Colors.black,
                                size: 30,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _isRecording
                          ? "Recording... ${_secondsRemaining}s remaining"
                          : "Tap to Record",
                      style: TextStyle(
                        color: _isRecording ? Colors.red : Colors.white54,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cameraController?.dispose();
    _countdownTimer?.cancel();
    _customTextController.dispose();
    _whatsappController.dispose();
    super.dispose();
  }
}
